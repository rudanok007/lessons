<?php
include("class/class.goods.php");


$phone = new Phone("Iphone", 64000, "Xs", 6.2, "Новый Iphone", 5, "img/Apple-iPhone-X.jpg");
$phone1 = new Phone("Huawei", 30210, "P30 PRO", 6.5, "Новый P30", 4, "img/p30pro.jpg");
$phone2 = new Phone("Xiaomi", 18000, "Mi 9", 6.4, "Новый Mi 9", 3, "img/mi9.jpg");
$tablet = new Tablet("Ipad", 66000, "4", 10.1, "Новый Ipad","4g", 5, "img/ipad4.jpeg");
$tablet1 = new Tablet("Huawei", 35210, "P20", 9.7, "Новый P32","3g", 5, "img/original.jpg");
$tablet2 = new Tablet("Xiaomi", 15000, "Tablet 8", 8.1, "Новый Tablet 8", "4g", 2.0, "img/s1200.jpg");

$phones = [$phone, $phone1, $phone2];
$tablets = [$tablet, $tablet1, $tablet2];



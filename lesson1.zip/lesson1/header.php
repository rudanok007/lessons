<?php

$menu = ["Главная" => "index.php",
        "Каталог" => "catalog.php",
        "О нас" => "about.php",
        "Контакты" => "contact.php"
];

?>
<div class="top-menu">
    <div class="navbar">
        <ul>
            <?php foreach($menu as $key => $val){ ?>
                <li><a href="<?= $val ?>"><?= $key ?></a></li>
            <?php } ?>
        </ul>
    </div>
</div>
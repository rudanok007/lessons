<?php
include_once("ext.class.goods.phone.php");
include_once("ext.class.goods.tablet.php");

class Goods {
    public $name;
    public $price;
    public $model;
    public $path;

    function __construct($name, $price, $model, $path){
        $this->name = $name;
        $this->price = $price;
        $this->model = $model;
        $this->path = $path;
    }

    function getName(){
        return $this->name;
    }
}
<?php

class Tablet extends Goods {
    public $inch;
    public $desc;
    public $modem;
    public $rating;
    

    public function __construct($name, $price, $model, $inch, $desc, $modem, $rating, $path){
        parent::__construct($name, $price, $model, $path);
        $this->inch = $inch;
        $this->desc = $desc;
        $this->rating = $rating;
        $this->modem = $modem;
        $this->path = $path;
        
    
    }
    
}
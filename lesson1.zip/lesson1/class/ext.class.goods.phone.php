<?php

class Phone extends Goods {
    public $inch;
    public $desc;
    public $rating;
    
   

    public function __construct($name, $price, $model, $inch, $desc, $rating, $path){
        parent::__construct($name, $price, $model, $path);
        $this->inch = $inch;
        $this->desc = $desc;
        $this->rating = $rating;
        $this->path = $path;
        
        
    }
}
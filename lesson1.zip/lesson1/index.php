<?php
include("functions.php");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style/style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">

<!-- Optional theme -->
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap-theme.min.css">

<!-- Latest compiled and minified JavaScript -->
<script src="//netdna.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>
    <title>Магазин товаров</title>
</head>
<body>
<div class="container">   
 <?php include("header.php"); ?>
 <div class="row">
    <div class="phones">
    <h4>Смартфоны</h4>
        <?php foreach($phones as $val){ ?>
            <div class="col-lg-4 col-md-4 col-xs-12 item">
                <h4><a href="#"><?= $val->name ?>&nbsp<?= $val->model ?></a></h4>
                <hr>
                <img src="<?= $val->path ?>" height="350" alt="">
                <hr>
                <span>Стоимость: <?= $val->price ?> рублей</span>
                <hr>
                <span>Диагональ: <?= $val->inch ?></span>
                <hr>
                <span>Описание: <?= $val->desc ?></span>
                <hr>
                <span>Рейтинг - <?= $val->rating ?></span>
                <?php for($i = 0; $i < $val->rating; $i++){ ?>
                    <img src="img/stars.png" height="20" alt="Звёздочка">
                <?php }?>
            </div>
        <?php } ?>
        </div>
        <div class="tablets">
        <h4>Планшеты</h4>
        <?php foreach($tablets as $val){ ?>
            <div class="col-lg-4 col-md-4 col-xs-12 item">
                <h4><a href="#"><?= $val->name ?>&nbsp<?= $val->model ?></a></h4>
                <hr>
                <img src="<?= $val->path ?>" height="350" alt="">
                <hr>
                <span>Стоимость: <?= $val->price ?> рублей</span>
                <hr>
                <span>Диагональ: <?= $val->inch ?></span>
                <hr>
                <span>Описание: <?= $val->desc ?></span>
                <hr>
                <span>Наличие модема: <?= $val->modem ?></span>
                <hr>
                <span>Рейтинг - <?= $val->rating ?></span>
                <?php for($i = 0; $i < $val->rating; $i++){ ?>
                    <img src="img/stars.png" height="20" alt="Звёздочка">
                <?php }?>
            </div>
        <?php } ?>
        </div>
    </div>
    </div>

</body>
</html>